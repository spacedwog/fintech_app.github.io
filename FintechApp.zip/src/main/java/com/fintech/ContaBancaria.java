package com.fintech;

/**
 * Classe ContaBancaria
 * Representa uma conta bancária digital vinculada a um cliente.
 */
public class ContaBancaria {

    private String numeroConta;
    private String agencia;
    private String tipoConta;
    private Double saldo;
    private String dataAbertura;
    private Cliente titular;

    // Construtor padrão
    public ContaBancaria() {
    }

    // Construtor com parâmetros
    public ContaBancaria(String numeroConta, String agencia, String tipoConta, Double saldo, String dataAbertura, Cliente titular) {
        this.numeroConta = numeroConta;
        this.agencia = agencia;
        this.tipoConta = tipoConta;
        this.saldo = saldo;
        this.dataAbertura = dataAbertura;
        this.titular = titular;
    }

    // Getters e Setters
    public String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        this.tipoConta = tipoConta;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void setTitular(Cliente titular) {
        this.titular = titular;
    }

    // Métodos
    public void depositar(Double valor) {
        System.out.println("Executando método depositar(): depositando R$ " + valor + " na conta " + numeroConta + ".");
    }

    public void sacar(Double valor) {
        System.out.println("Executando método sacar(): sacando R$ " + valor + " da conta " + numeroConta + ".");
    }

    public void transferir(String contaDestino, Double valor) {
        System.out.println("Executando método transferir(): transferindo R$ " + valor + " da conta " + numeroConta + " para a conta " + contaDestino + ".");
    }

    public void consultarSaldo() {
        System.out.println("Executando método consultarSaldo(): consultando o saldo da conta " + numeroConta + ".");
    }

    public void encerrarConta() {
        System.out.println("Executando método encerrarConta(): encerrando a conta " + numeroConta + ".");
    }
}
