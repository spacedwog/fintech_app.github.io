package com.fintech;

/**
 * Classe Cliente
 * Representa um cliente cadastrado no sistema Fintech.
 */
public class Cliente {

    private String nome;
    private String cpf;
    private String email;
    private String telefone;
    private String dataNascimento;
    private String endereco;
    private Boolean ativo;

    // Construtor padrão
    public Cliente() {
    }

    // Construtor com parâmetros
    public Cliente(String nome, String cpf, String email, String telefone, String dataNascimento, String endereco) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.endereco = endereco;
        this.ativo = true;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    // Métodos
    public void cadastrar() {
        System.out.println("Executando método cadastrar(): cadastrando o cliente " + nome + " no sistema Fintech.");
    }

    public void atualizarDados() {
        System.out.println("Executando método atualizarDados(): atualizando os dados cadastrais do cliente " + nome + ".");
    }

    public void exibirDados() {
        System.out.println("Executando método exibirDados(): exibindo os dados do cliente " + nome + ".");
    }

    public void inativarCliente() {
        System.out.println("Executando método inativarCliente(): inativando o cadastro do cliente " + nome + " no sistema.");
    }
}
