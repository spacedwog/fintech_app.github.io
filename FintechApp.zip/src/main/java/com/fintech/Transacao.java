package com.fintech;

/**
 * Classe Transacao
 * Representa uma movimentação financeira realizada entre contas.
 */
public class Transacao {

    private Integer idTransacao;
    private String tipoTransacao;
    private Double valor;
    private String dataHora;
    private String contaOrigem;
    private String contaDestino;
    private String status;

    // Construtor padrão
    public Transacao() {
    }

    // Construtor com parâmetros
    public Transacao(Integer idTransacao, String tipoTransacao, Double valor, String dataHora, String contaOrigem, String contaDestino) {
        this.idTransacao = idTransacao;
        this.tipoTransacao = tipoTransacao;
        this.valor = valor;
        this.dataHora = dataHora;
        this.contaOrigem = contaOrigem;
        this.contaDestino = contaDestino;
        this.status = "PENDENTE";
    }

    // Getters e Setters
    public Integer getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(Integer idTransacao) {
        this.idTransacao = idTransacao;
    }

    public String getTipoTransacao() {
        return tipoTransacao;
    }

    public void setTipoTransacao(String tipoTransacao) {
        this.tipoTransacao = tipoTransacao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getDataHora() {
        return dataHora;
    }

    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }

    public String getContaOrigem() {
        return contaOrigem;
    }

    public void setContaOrigem(String contaOrigem) {
        this.contaOrigem = contaOrigem;
    }

    public String getContaDestino() {
        return contaDestino;
    }

    public void setContaDestino(String contaDestino) {
        this.contaDestino = contaDestino;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Métodos
    public void processarTransacao() {
        System.out.println("Executando método processarTransacao(): processando transação " + idTransacao + " no valor de R$ " + valor + ".");
    }

    public void cancelarTransacao() {
        System.out.println("Executando método cancelarTransacao(): cancelando a transação " + idTransacao + ".");
    }

    public void gerarComprovante() {
        System.out.println("Executando método gerarComprovante(): gerando comprovante da transação " + idTransacao + ".");
    }

    public void consultarStatus() {
        System.out.println("Executando método consultarStatus(): consultando status da transação " + idTransacao + ".");
    }
}
