package com.fintech;

/**
 * Classe CartaoCredito
 * Representa um cartão de crédito emitido para um cliente da Fintech.
 */
public class CartaoCredito {

    private String numeroCartao;
    private String nomeTitular;
    private String dataValidade;
    private Integer cvv;
    private Double limiteCredito;
    private Double limiteDisponivel;
    private Boolean ativo;

    // Construtor padrão
    public CartaoCredito() {
    }

    // Construtor com parâmetros
    public CartaoCredito(String numeroCartao, String nomeTitular, String dataValidade, Integer cvv, Double limiteCredito) {
        this.numeroCartao = numeroCartao;
        this.nomeTitular = nomeTitular;
        this.dataValidade = dataValidade;
        this.cvv = cvv;
        this.limiteCredito = limiteCredito;
        this.limiteDisponivel = limiteCredito;
        this.ativo = false;
    }

    // Getters e Setters
    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }

    public String getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(String dataValidade) {
        this.dataValidade = dataValidade;
    }

    public Integer getCvv() {
        return cvv;
    }

    public void setCvv(Integer cvv) {
        this.cvv = cvv;
    }

    public Double getLimiteCredito() {
        return limiteCredito;
    }

    public void setLimiteCredito(Double limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public Double getLimiteDisponivel() {
        return limiteDisponivel;
    }

    public void setLimiteDisponivel(Double limiteDisponivel) {
        this.limiteDisponivel = limiteDisponivel;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    // Métodos
    public void ativarCartao() {
        System.out.println("Executando método ativarCartao(): ativando o cartão " + numeroCartao + " do titular " + nomeTitular + ".");
    }

    public void bloquearCartao() {
        System.out.println("Executando método bloquearCartao(): bloqueando o cartão " + numeroCartao + ".");
    }

    public void realizarCompra(Double valor) {
        System.out.println("Executando método realizarCompra(): realizando compra de R$ " + valor + " no cartão " + numeroCartao + ".");
    }

    public void pagarFatura(Double valor) {
        System.out.println("Executando método pagarFatura(): pagando fatura de R$ " + valor + " do cartão " + numeroCartao + ".");
    }

    public void aumentarLimite(Double valorAdicional) {
        System.out.println("Executando método aumentarLimite(): aumentando o limite do cartão " + numeroCartao + " em R$ " + valorAdicional + ".");
    }
}
