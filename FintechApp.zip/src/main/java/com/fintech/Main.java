package com.fintech;

/**
 * Classe Main
 * Ponto de entrada da aplicação. Instancia os objetos do sistema Fintech
 * e chama seus métodos para demonstração.
 */
public class Main {

    public static void main(String[] args) {

        Cliente cliente = new Cliente("Felipe Santos", "123.456.789-00", "felipe@email.com",
                "(11) 99999-0000", "1988-05-10", "Rua das Flores, 100");
        cliente.cadastrar();
        cliente.exibirDados();

        ContaBancaria conta = new ContaBancaria("00123456-7", "0001", "Corrente", 1500.00, "2026-01-15", cliente);
        conta.depositar(500.00);
        conta.sacar(200.00);
        conta.consultarSaldo();

        CartaoCredito cartao = new CartaoCredito("1234 5678 9012 3456", "Felipe Santos", "12/2030", 123, 5000.00);
        cartao.ativarCartao();
        cartao.realizarCompra(350.00);
        cartao.pagarFatura(350.00);

        Transacao transacao = new Transacao(1, "TED", 500.00, "2026-08-04 10:30", "00123456-7", "00987654-3");
        transacao.processarTransacao();
        transacao.gerarComprovante();

        Investimento investimento = new Investimento(1, "CDB", 1000.00, 0.012, "2026-08-04", cliente);
        investimento.aplicar(1000.00);
        investimento.calcularRendimento();
    }
}
