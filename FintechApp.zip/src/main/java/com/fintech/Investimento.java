package com.fintech;

/**
 * Classe Investimento
 * Representa uma aplicação financeira contratada por um cliente.
 */
public class Investimento {

    private Integer idInvestimento;
    private String tipoInvestimento;
    private Double valorAplicado;
    private Double taxaRendimento;
    private String dataAplicacao;
    private Cliente investidor;

    // Construtor padrão
    public Investimento() {
    }

    // Construtor com parâmetros
    public Investimento(Integer idInvestimento, String tipoInvestimento, Double valorAplicado, Double taxaRendimento, String dataAplicacao, Cliente investidor) {
        this.idInvestimento = idInvestimento;
        this.tipoInvestimento = tipoInvestimento;
        this.valorAplicado = valorAplicado;
        this.taxaRendimento = taxaRendimento;
        this.dataAplicacao = dataAplicacao;
        this.investidor = investidor;
    }

    // Getters e Setters
    public Integer getIdInvestimento() {
        return idInvestimento;
    }

    public void setIdInvestimento(Integer idInvestimento) {
        this.idInvestimento = idInvestimento;
    }

    public String getTipoInvestimento() {
        return tipoInvestimento;
    }

    public void setTipoInvestimento(String tipoInvestimento) {
        this.tipoInvestimento = tipoInvestimento;
    }

    public Double getValorAplicado() {
        return valorAplicado;
    }

    public void setValorAplicado(Double valorAplicado) {
        this.valorAplicado = valorAplicado;
    }

    public Double getTaxaRendimento() {
        return taxaRendimento;
    }

    public void setTaxaRendimento(Double taxaRendimento) {
        this.taxaRendimento = taxaRendimento;
    }

    public String getDataAplicacao() {
        return dataAplicacao;
    }

    public void setDataAplicacao(String dataAplicacao) {
        this.dataAplicacao = dataAplicacao;
    }

    public Cliente getInvestidor() {
        return investidor;
    }

    public void setInvestidor(Cliente investidor) {
        this.investidor = investidor;
    }

    // Métodos
    public void aplicar(Double valor) {
        System.out.println("Executando método aplicar(): aplicando R$ " + valor + " no investimento " + tipoInvestimento + ".");
    }

    public void resgatar(Double valor) {
        System.out.println("Executando método resgatar(): resgatando R$ " + valor + " do investimento " + idInvestimento + ".");
    }

    public void calcularRendimento() {
        System.out.println("Executando método calcularRendimento(): calculando o rendimento do investimento " + idInvestimento + ".");
    }

    public void encerrarInvestimento() {
        System.out.println("Executando método encerrarInvestimento(): encerrando o investimento " + idInvestimento + ".");
    }
}
